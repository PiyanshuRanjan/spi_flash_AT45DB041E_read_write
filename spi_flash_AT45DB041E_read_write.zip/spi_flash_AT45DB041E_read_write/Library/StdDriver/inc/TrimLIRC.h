extern void Trim_LIRC(void);
extern void Trim_LIRC_32768(void);