void LowPower_LIRC_UART2_4800_init(void);
void LowPower_LIRC_UART2_9600_init(void);
void LowPower_UART2_Send_Data( unsigned char c);
void onestop_9600(void);
void twostop_9600(void);

