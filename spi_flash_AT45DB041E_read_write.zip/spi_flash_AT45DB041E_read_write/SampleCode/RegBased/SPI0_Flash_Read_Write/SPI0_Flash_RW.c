
#include "MUG51.h"


#define SPI_CMD_READ     								0xD2
#define SPI_CMD_READ_ARRAY     					0x0B

#define SPI_CMD_WRITE  				        	0x02

#define SPI_CMD_WRITE_BUFFER1  					0x82 //0x84
#define SPI_CMD_WRITE_BUFFER2  					0x87

#define AT45DB041E_BUFFER1_TO_PAGE 			0x88 
#define AT45DB041E_BUFFER2_TO_PAGE			0x89 


#define SPI_CMD_CHIP_ERASE      				0xC7
#define DUMMY_DATA      								0xEE

#define MAX_WRITE_SIZE 									256
#define MAX_READ_SIZE  									256

#define SPI0_SS_PIN             P03   
/***************************************************/
unsigned char block, sector, page;
unsigned int loop , maddress;
unsigned char u8MID,u8DID;
unsigned char MID, DI1, DI2, EDI, EDI1;
unsigned char write_data[256];
unsigned char read_data[256];
/***************************************************/
void SPI_Initial(void)
{
    MFP_P00_SPI0_MOSI;      
    P00_QUASI_MODE;
    MFP_P01_SPI0_MISO;      
    P01_QUASI_MODE;
    MFP_P02_SPI0_CLK;       
    P02_QUASI_MODE;
    MFP_P03_GPIO;           
    P03_PUSHPULL_MODE; 

    clr_SPI0CR0_SPR1;
    clr_SPI0CR0_SPR0;
/* /SS General purpose I/O ( No Mode Fault ) */
    set_SPI0SR_DISMODF;
    clr_SPI0CR0_SSOE;

    /* SPI in Master mode */
    set_SPI0CR0_MSTR;

    /* MSB first */
    clr_SPI0CR0_LSBFE;

    clr_SPI0CR0_CPOL;
    clr_SPI0CR0_CPHA;
    
    /* Enable SPI function */
    set_SPI0CR0_SPIEN;
}


/****************************************************************/
void SpiFlash_Read_ALL_ID(unsigned char u8SPISel, unsigned char *pu8A, unsigned char *pu8B, unsigned char *pu8C, unsigned char *pu8D, unsigned char *pu8E)
{
    SPI0_SS_PIN = 0;
    Spi_Write_Byte(u8SPISel,0x9F);
    *pu8A = Spi_Read_Byte(u8SPISel,0xFF);
    *pu8B = Spi_Read_Byte(u8SPISel,0xFF);
		*pu8C = Spi_Read_Byte(u8SPISel,0xFF);
		*pu8D = Spi_Read_Byte(u8SPISel,0xFF);
		*pu8E = Spi_Read_Byte(u8SPISel,0xFF);
    SPI0_SS_PIN = 1;
}

/****************************************************************/

void SpiFlash_write(uint32_t u_address, uint32_t wr_data_size)
{
		uint8_t ad1 = (u_address >> 16) & 0xff;
		uint8_t ad2 =	(u_address >> 8) & 0xff;	
	  uint8_t ad3 =	u_address & 0xff;
	
		SPI0_SS_PIN = 0;
    Spi_Write_Byte(SPI0,SPI_CMD_WRITE_BUFFER1);
    Spi_Write_Byte(SPI0, ad1);   
    Spi_Write_Byte(SPI0, ad2);     
    Spi_Write_Byte(SPI0, ad3);
		
		for(loop = 0; loop < wr_data_size; loop++)
		{
			write_data[loop] = loop;
			read_data[loop] = 0x55;
			Spi_Write_Byte(SPI0, write_data[loop]);
			
		}
		SPI0_SS_PIN = 1;
	
}	

/****************************************************************/


void SpiFlash_read(uint32_t u_address, uint32_t rd_data_size)
{
		uint8_t ad1 = (u_address >> 16) & 0xff;
		uint8_t ad2 =	(u_address >> 8) & 0xff;	
	  uint8_t ad3 =	u_address & 0xff;
	
	
		SPI0_SS_PIN = 0;
    Spi_Write_Byte(SPI0,SPI_CMD_READ_ARRAY);
    Spi_Write_Byte(SPI0, ad1);   
    Spi_Write_Byte(SPI0, ad2);     
    Spi_Write_Byte(SPI0, ad3);	
		Spi_Write_Byte(SPI0, DUMMY_DATA);
		for(loop = 0; loop < rd_data_size; loop++)
		{
			read_data[loop] = Spi_Read_Byte(SPI0,0x05);
		}
		SPI0_SS_PIN = 1;	
}	



void main(void)
{
		uint32_t user_address;
	
		SPI_Initial();
			
		user_address = 0x000000;
		
		SpiFlash_Read_ALL_ID(SPI0, &MID, &DI1, &DI2, &EDI, &EDI1);
	
		SpiFlash_write(0x000000, MAX_READ_SIZE);
		SpiFlash_read(0x000000, MAX_READ_SIZE);
	
		SpiFlash_write(0x002000, MAX_READ_SIZE);
		SpiFlash_read(0x002000, MAX_READ_SIZE);
	
		SpiFlash_write(0x100000, MAX_READ_SIZE);
		SpiFlash_read(0x100000, MAX_READ_SIZE);

		SpiFlash_write(0xf10000, MAX_READ_SIZE);
		SpiFlash_read(0xf10000, MAX_READ_SIZE);


}
